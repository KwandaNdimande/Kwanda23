/**
 * 
 */
/**
 * 
 */
module StarsQ1 {
}